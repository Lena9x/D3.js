/*Code for map was adapted from https://d3-graph-gallery.com/graph/bubblemap_circleFeatures.html */ 
/*Code for Bar Graph was adapted from https://d3-graph-gallery.com/graph/barplot_basic.html */
/***************************************************************
           The Map Scales
***************************************************************/
//the dimensions
var colorScale;
let countryData; 

const marg = { top: 40, right: 0, bottom: 40, left: 20 };
const wei = 700 - marg.left - marg.right;
const hei = 700 - marg.bottom;
const adj = 1;
/***************************************************************
           Load Data
***************************************************************/
d3.json("New_output.json").then(data => {
  // Extract required fields
  const markers = data.map(d => ({
    month: d['Month'],
    parentOrg: d['Parent Org'],
    hospitalName: d['Hospital name'],
    latitude: +d['Latitude'],
    longitude: +d['Longitude'],
    type1:parseInt(d['A&E attendances Type 1'],10),
    type2:parseInt(d['A&E attendances Type 2'],10),
    other:parseInt(d['A&E attendances Other A&E Department'],10),
  }));
/***************************************************************
           Create the Map  - Append the SVG to the chart area
***************************************************************/
  const map = d3.select('body .main .chartbody #chart')
                .select('svg')
                .attr("width", wei)
                .attr("height", hei)
                .attr("viewBox", "-"
                  + adj + " -"
                  + adj + " "
                  + (wei +adj * 100) + " "
                  + (hei + adj * 2))
                .attr('margin', '.5rem')
                .attr('preserveAspectRatio', 'xMidYMid')
                .attr('style','max-width:100%; height: auto;')
                .append("g")
        ;
/****************************************************************************
 Create the Bar Chart  - Append the SVG to the BarGraph area
*****************************************************************************/
const barmargin = { top: 50, right: 30, bottom: 70, left: 60 };
const barwidth = 600 -  barmargin.left
const barheight = 700 - barmargin.top - barmargin.bottom
padding =  barmargin.left - barmargin.right;
// Create SVG element for the bar chart
const barsvg = d3.select("#BarGraphSVG")
  .attr("width",barwidth -padding) 
  .attr("height", barheight +padding)
  .append("g")
  .attr('margin-left', padding)
  .attr('margin', '.8rem')
  .attr('preserveAspectRatio', 'xMidYMid')
  .attr("style", "max-width: 100%; height: auto;")
  ;

// Define the data for the bar chart
const axis_labels = ["Type 1", "Type 2", "Other"];
const values = [
  d3.sum(markers, d => d.type1),
  d3.sum(markers, d => d.type2),
  d3.sum(markers, d => d.other),
];

// Create scales for x and y axes
const xScale = d3.scaleBand()
  .domain(axis_labels)
  .range([80, barwidth-barmargin.left])
  .padding(0.2);

/***************************************************************
   This is the Code for the Bar Chart
***************************************************************/  
const maxBarHeight = (d3.max(values)) ;
const yScale = d3.scaleLinear()
  .domain([0, maxBarHeight])
  .range([barheight, 0])
  .nice(0.5)

// Add X axis to the bar chart
const xAxis =barsvg.append("g")
  .attr("class", "x-axis") // Add class name here
  .attr("transform", "translate(0," + barheight + ")")
  .call(d3.axisBottom(xScale));

// Add Y axis to the bar chart
const yAxis = barsvg.append("g")
                  .attr("class", "y-axis")
                  .attr("transform", `translate(80,0) `)
                    .call(d3.axisLeft(yScale));

//Barchart title 
const hospitalNameText = d3.select("#bartitle")  
  .append("text")
  .attr("class", "hospital-name")
  .attr("x", barwidth / 2)
  .attr("y", -10) // Position it at the top
  .attr("text-anchor", "middle")
  .attr("fill", "black")
  .attr("font-size", "14px")
  .attr("font-weight", "bold");

const bar_colours = (['#1f77b4','#d62728','#2ca02c'])

//Add bars to the bar chart
barsvg.selectAll("rect")
    .data(values)
    .join("rect") 
    .attr("x", (d, i) => xScale(axis_labels[i]))
    .attr("y", d =>  yScale(d))
    .attr("width", xScale.bandwidth())
    .attr("height", d => barheight - yScale(d))
    .attr("fill", (d, i) => bar_colours[i]) 
    .transition() 
    .duration(500);


/**********************************************************
   Projections for Map
************************************************************/
const projection = d3.geoMercator().center([-4, 55])
                        .scale(2700)
                        .rotate([0, 0])
                        .translate([wei / 2, hei / 2]);
const path = d3.geoPath()
                .projection(projection);



d3.json("ukcounties.json").then(Geo => {
  const world = map
    .append("g")
    .selectAll("path")
    .data(Geo.features)
    .enter()
    .append("path")
    .attr("id", (d) => d.properties.name)
    .attr('d', path)
    .style("fill", "#99d993")
    .style("stroke", "black")
    .attr("stroke-width", 2)
    .style("opacity", 1)
    .attr("transform", `translate(10,0)`);
/***************************************************************
  Function to update Bar chart when circles are hovered over
***************************************************************/ 

function updateBarGraph(selectedValue, ismonth) {
  let filteredData;
  if (ismonth) {
    filteredData = markers.filter(d => d.month === selectedValue);
  } 
  else {
    filteredData = markers.filter(d => d.hospitalName === selectedValue);
  }

  const values = [
      d3.sum(filteredData, d => d.type1),
      d3.sum(filteredData, d => d.type2),
      d3.sum(filteredData, d => d.other),
  ];

  // Update Y axis scale domain
  yScale.domain([0, d3.max(values)]);

  // Adjust the height of each bar so that it never exceeds the maximum height
  barsvg.selectAll("rect")
    .data(values)
    .transition()
    .duration(500)
    .attr("y", d => yScale(d))
    .attr("height", d => barheight - yScale(d));

  // Update X axis
  barsvg.select(".x-axis")
      .transition()
      .duration(500)
      .call(d3.axisBottom(xScale));

  hospitalNameText.text(selectedValue);
  // Update Y axis
  barsvg.select(".y-axis")
      .transition()
      .duration(500)
      yAxis.call(d3.axisLeft(yScale).ticks(5)); 
}
/***************************************************************
           Drop Down Menu (Date Selector)
***************************************************************/   
const uniquemonths = Array.from(new Set(markers.map(d => d.month)));
// Create a dropdown menu dynamically for months
const monthSelector = d3.select("#dropdown-container")
  .append("select")
  .attr("id", "month-selector");

monthSelector.selectAll("option")
  .data(uniquemonths)
  .enter()
  .append("option")
  .attr("value", d => d)
  .text(d => d);


// Attach event listener to the dropdown menu
monthSelector.on("change", function () {
  const selectedMonth = this.value; // Get the selected month
  // Update the bar graph based on the selected month
  updateBarGraph(selectedMonth);
});


// Add mouseover event listener to circles
map.selectAll(".circle")
    .on("mouseover", function (event, d) {
        const hospitalName = d.hospitalName;
        updateBarGraph(hospitalName, false);
        // Update the Y-axis
        barsvg.select(".y-axis")
            .transition()
            .duration(500)
            .call(d3.axisLeft(yScale).ticks(5)); 
});

/***************************************************************
         Map tooltip
***************************************************************/
// create a tooltip for map
const Tooltip = d3.select(".chartbody #chart")
    .append("div")
    .attr("class", "tooltip")
    .style("opacity", 0)
    .style("background-color", "black")
    .style("color", "white")
    .style("border", "solid")
    .style("border-width", "2px")
    .style("border-radius", "15px")
    .style("padding", "5px")
    .style("position", "absolute");

    var mouseover = function(event, d) {
        const hospitalName = d.hospitalName;
        updateBarGraph(hospitalName, false);
    
        // Show tooltip
        Tooltip.transition()
            .duration(200)
            .style("opacity", 0.7);
    
        // Set tooltip content
        Tooltip.html(d.hospitalName + "<br>" + d.parentOrg +"<br>"+ "longitude: " + d.longitude + "<br>" + "latitude: " + d.latitude + "<br>")
            .style("top", `${event.y + 10}px`)
            .style("transform", "translateX(20rem)");
        
        barsvg.select(".hospital-name")
        .text(hospitalName)
        .attr("x", barwidth / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .attr("fill", "black")
        .attr("font-size", "14px")
        .attr("font-weight", "bold");

          };
    
    var mouseleave = function(event, d) {
        // Hide tooltip
        Tooltip.transition()
            .duration(200)
            .style("opacity", 0);
    };
   
    // Add mouseover and mouseleave event listeners to circles
    map.selectAll(".circle")
        .on("mouseover", mouseover)
        .on("mouseleave", mouseleave);


/***************************************************************
    Bar chart tooltip Interactions
***************************************************************/ 
const bartooltip = d3.select("body")
.append("div")
.attr("class", "bartooltip")
.style("opacity", 0)
.style("background-color", "black")
.style("color", "white")
.style("border", "solid")
.style("width", "200px")
.style("border-width", "2px")
.style("border-radius", "15px")
.style("padding", "5px")
.style("position", "absolute");

var barmouseover = function(event, d, i) {
  // Show tooltip
  bartooltip.transition()
    .duration(200)
    .style("opacity", 0.7);
  // Get the value associated with the hovered bar
  var value = d; 

  // Set tooltip content
  bartooltip.html("Number of admissions: " + value)
    .style("top", `${event.pageY + 10}px`) 
    .style("left", `${event.pageX + 10}px`); 
};

var barmouseleave = function(event, d) {
  // Hide tooltip
  bartooltip.transition()
    .duration(200)
    .style("opacity", 0);
};

// Add mouseover and mouseleave event listeners to bars
d3.selectAll("g rect")
  .on("mouseover", barmouseover)
  .on("mouseleave", barmouseleave);
/***************************************************************
           Add circles to map
***************************************************************/ 
var circleColor = d3.scaleOrdinal()
.domain(['NHS ENGLAND MIDLANDS','NHS ENGLAND SOUTH WEST','NHS ENGLAND NORTH WEST','NHS ENGLAND SOUTH EAST','NHS ENGLAND NORTH EAST AND YORKSHIRE','NHS ENGLAND EAST OF ENGLAND','NHS ENGLAND LONDON'])
.range(['#53b053','#e68fcb','#a682c7','#fc963b','#db4f50','#a0756c','#498fc0']
);
 
map
  .selectAll("myCircles")
  .data(markers)
  .join("circle")
    .attr("cx", d => projection([d.longitude, d.latitude])[0])
    .attr("cy", d => projection([d.longitude, d.latitude])[1])
    .attr("r", 10)
    .attr("class", "circle")
    .style("fill", (d)=>  circleColor(d.parentOrg))
    .attr("stroke", "black")
    .attr("stroke-width", 1)
    .on("mouseover", mouseover)
    .on("mouseleave", mouseleave)
/***************************************************************
           Map Zoom functions
***************************************************************/ 
var zoom = d3.zoom()
  .scaleExtent([1, 8])
  .on('zoom', function (event) {
    map.selectAll('path')
      .attr('transform', event.transform);
      
  // Update circle positions during zoom
    map.selectAll('.circle')
      .attr("cx", d => event.transform.apply(projection([d.longitude, d.latitude]))[0])
      .attr("cy", d => event.transform.apply(projection([d.longitude, d.latitude]))[1]);
});

// Call zoom here
map.call(zoom);
});
});
/***************************************************************
           Map Legend
***************************************************************/ 

 // Define regions and colors
 var regions = ['NHS ENGLAND MIDLANDS','NHS ENGLAND SOUTH WEST','NHS ENGLAND NORTH WEST','NHS ENGLAND SOUTH EAST','NHS ENGLAND NORTH EAST AND YORKSHIRE','NHS ENGLAND EAST OF ENGLAND','NHS ENGLAND LONDON'];
 var colors = ['#53b053','#e68fcb','#a682c7','#fc963b','#db4f50','#a0756c','#498fc0'];

 // Append legend
 var legend = d3.select("#legend")
     .selectAll(".legend-item")
     .data(regions)
     .enter().append("g")
     .attr("class", "legend-item")
     .attr("transform", function(d, i) {
         return "translate(10," + (i * 20) + ")";
     });

 legend.append("rect")
     .attr("width", 10)
     .attr("height", 10)
     .style("fill", function(d, i) {
         return colors[i];
     });

 legend.append("text")
     .attr("x", 20)
     .attr("y", 10)
     .text(function(d) {
         return d;
     });