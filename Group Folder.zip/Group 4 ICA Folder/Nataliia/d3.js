/***************************************************************
           Th Pie chart
***************************************************************/

// constant dimensions , radius and color scale for SVG
    const width = 960;
    const height = 500;
    const radius = Math.min(width, height)/2;
    const color = d3.scaleOrdinal(d3.schemeCategory10);


// Create arc generator
    const arc = d3.arc()
        .outerRadius(radius -10)
        .innerRadius(radius -100);

//Create SVG element
    const svg = d3.select("body").append("svg")
                    .attr("width", width)
                    .attr("height", height)
                    .style("background", "white")
                    .append("g")
                    .attr("transform", "translate(" + width/2+ "," +height/2 +")");
/***************************************************************
           Load Data
***************************************************************/

// Load json file
    d3.json("NAtaliia.json")
        .then(buildPieChart)
        .catch(function (error){
            d3.select(".error")
                .style("visibility", "visible")
                .text("There was an error fetching the data")
    });


   function buildPieChart(jsonData){
        console.log(jsonData);

    //Creating an array of objects representing the A E attendance types
    const aggData = jsonData.reduce((acc, curr) =>{
        acc["Type 1"] = (acc["Type 1"] || 0) + curr['A&E attendances Type 1'];
        acc["Type 2"] = (acc["Type 2"] || 0) + curr['A&E attendances Type 2'];
        acc["Other Admissions"] = (acc["Other Admissions"] || 0) + curr['A&E attendances Other A&E Department'];
        return acc;
    }, {});


    // Extract  "Parent Org " field from each object
    const parOrgVal = jsonData.map(obj => obj["Parent Org"]);
    const unique = new Set(parOrgVal);
    const uniqueArr = Array.from(unique);

    // Extract  "Month" field from each object
    const mouths = jsonData.map(obj => obj["Month"]);
    const uniqueMonths = new Set(mouths);
    const uniqM = Array.from(uniqueMonths);
/****************************************************************************
           Create the Dropdown
*********************************************************************/
//Select the dropdown element with ID
    d3.select("#selectButton")
        .selectAll("option")
        .data(uniqueArr)
        .enter()
        .append("option")
        .attr("value", function(d){return d;})
        .text(function(d) { return d;});

// Update the pie chart based on the filter
    d3.select("#selectButton").on("change", function(){
        const selVal = d3.select(this).property("value");
        const filData = jsonData.filter(obj => obj["Parent Org"] === selVal);
        updateVisual(filData);
    });
// Select the dropdown element with ID "selectButton2"
    d3.select("#selectButton2")
        .selectAll("option")
        .data(uniqM)
        .enter()
        .append("option")
        .attr("value", function(d){return d;})
        .text(function(d) { return d;});

// Update the pie chart based on the filter
    d3.select("#selectButton2").on("change", function(){
        const selM = d3.select(this).property("value");
        const filM = jsonData.filter(obj => obj["Month"] === selM);
        updateVisual(filM);

    });



    updateVisual(jsonData);

   }

    function updateVisual(data){

    const aggData = data.reduce((acc, curr) => {
        acc["Type 1"] = (acc["Type 1"] || 0) + curr['A&E attendances Type 1'];
        acc["Type 2"] = (acc["Type 2"] || 0) + curr['A&E attendances Type 2'];
        acc["Type 3"] = (acc["Type 3"] || 0) + curr['A&E attendances Other A&E Department'];
        return acc;
    }, {});
console.log(aggData)

/***************************************************************
           Create the Bar Chart - Append the SVG this part taken from https://d3-graph-gallery.com/graph/line_filter.html
***************************************************************/

    const pieD = Object.keys(aggData).map(type => ({ type, count: aggData[type] }));
    console.log("Pie", pieD)
    const pie = d3.pie()
            .value(d=>d.count);


    const selections = svg.selectAll("path")
                            .data(pie(pieD));
    console.log("Selections:", selections);



    selections.transition()
              .duration(1000)
              .attrTween("d", function(d) {
                    var interpolate = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
                    return function(t) {
                        return arc(interpolate(t));
                    };
              });


    selections.exit().remove()


/****************************************************************************
          Setup tooltip
*********************************************************************/

// Tooltip setup
  const tooltip  = d3.select("#tooltip")
                    .style("opacity", 0)
                    .style("background-color", "black")
                    .style("color", "white")
                    .style("border", "solid")
                    .style("border-width", "2px")
                    .style("border-radius", "15px")
                    .style("padding", "5px")
                    .style("position", "absolute")

// Mouseover function for tooltip
 const mouseover = function(event,d ) {
            console.log("mouseover event", event );
            console.log ("Data" , d);
            tooltip.transition()
                    .duration(200)
                    .style("opacity", 1);
             tooltip.html(`<strong>Type: ${d.data.type}<br/>Count: ${d.data.count}</strong>`)
                    .style("left", (event.pageX) + "px")
                    .style("top", (event.pageY - 28) + "px");
 };

//Mouseleave function for tooltip
 const mouseleave = function(event , d ){
            console.log("mouseleave event:", event);
            console.log("Data:", d);
            tooltip.transition()
               .duration(200)
               .style ("opacity", 0);
 };
 /****************************************************************************
            Function to Update
*********************************************************************/

 // Enter new path with transitions
        selections.enter()
               .append("path")
               .data(pie(pieD))
               .attr("fill", d => color(d.data.type))
               .on("mouseover", function(event, d) { mouseover(event, d); })
               .on("mouseleave", function(event, d) { mouseleave(event, d); })
               .transition()
               .duration(1000)
               .attrTween("d", function(d) {
                     var interpolate = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
                     return function(t) {
                                return arc(interpolate(t));
                      };
               });
/****************************************************************************
         Legend
*********************************************************************/
//Legend setup
    const legend = svg.append("g")
        .attr("transform", "translate(100,100)")
        .selectAll(".legend")
        .data(pieD)
        .enter()
        .append("g")
        .classed("legends", true).attr("transform", function (d, i) { return "translate(0," + (i + 1) * 30 + ")"; });
    legend.append("rect")
        .attr("width", 20)
        .attr("height", 20)
        .attr("x", 190)
        .attr("y", -15)
        .attr("fill", d => color(d.type));
    legend.append("text")
        .text(d => d.type)
        .attr("fill", d => color(d.type))
        .attr("x", 220)
        .attr("y", 2);

}