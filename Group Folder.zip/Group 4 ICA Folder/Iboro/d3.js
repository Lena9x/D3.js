/***************************************************************
           Load the dataset from JSON file
***************************************************************/    
        d3.json("data2.json").then(function(dataset) {
            // Extract unique years from the dataset
            const uniqueYears = Array.from(new Set(dataset.map(d => d.Year)));
/***************************************************************
           Year slicer
***************************************************************/    
            // Populate the dropdown menu with year options
            const yearSelector = d3.select("#yearSelector");
            yearSelector.selectAll("option")
                .data(uniqueYears)
                .enter()
                .append("option")
                .attr("value", d => d)
                .text(d => d);

            // Define color scale
            const colorScale = d3.scaleOrdinal()
                .domain(dataset.map(d => d.OrgCode))
                .range(d3.schemeCategory10);

            // Function to update the chart based on the selected year
            function updateChart(selectedYear) {
                // Filter dataset by selected year
                const filteredData = dataset.filter(d => d.Year == selectedYear);

                // Calculate the sum for each organization
                const summedData = d3.rollup(filteredData, v => d3.sum(v, d => d.TotalAdmissions), d => d.OrgCode);

                // Convert the summed data to an array of objects and sort in descending order
                let summedArray = Array.from(summedData, ([OrgCode, TotalAdmissions]) => ({ OrgCode, TotalAdmissions }));
                summedArray.sort((a, b) => b.TotalAdmissions - a.TotalAdmissions);

                // Keep only the top 10 entries
                summedArray = summedArray.slice(0, 10);

                // Remove existing SVG
                d3.select("svg").remove();
/***************************************************************
                Create SVG
***************************************************************/    
 
                // SVG size
                const width = 1300; // Reduced width
                const height = 600; // Reduced height

                // Margins
                const margin = { top: 50, right: 50, bottom: 50, left: 150 }; // Adjusted margins for alignment

                // The actual chart size within the SVG area.
                const graphWidth = width - margin.left - margin.right;
                const graphHeight = height - margin.top - margin.bottom;

                // Create an SVG to draw to
                const svg = d3.select(".chart")
                    .append("svg")
                    .attr("width", width)
                    .attr("height", height);
/***************************************************************
                  Title Axis
***************************************************************/    
 
                 // Add x-axis title
                svg.append("text")
                    .attr("class", "axis-title")
                    .attr("transform", `translate(${margin.left + graphWidth / 2},${height - margin.bottom / 8})`)
                    .style("text-anchor", "middle")
                    .style("font-weight", "bold") // Make the labels bold
                    .text("OrgCode");

                // Add y-axis title
                svg.append("text")
                    .attr("class", "axis-title")
                    .attr("transform", `translate(${margin.left / 2},${margin.top + graphHeight / 2}) rotate(-90)`)
                    .style("text-anchor", "middle")
                    .style("font-weight", "bold") // Make the labels bold
                    .text("TotalAdmissions");
   

                // Create a group to contain the whole graph.
                const plotArea = svg.append('g')
                    .attr("transform", `translate(${margin.left},${margin.top})`);
/***************************************************************
                      Bar Chart
***************************************************************/    
 
                // Set up bar chart
                const xScale = d3.scaleBand()
                    .domain(summedArray.map(d => d.OrgCode))
                    .range([0, graphWidth])
                    .padding(0.1);

                const yScale = d3.scaleLinear()
                    .domain([0, d3.max(summedArray, d => d.TotalAdmissions)])
                    .nice()
                    .range([graphHeight, 0]);

                // Add bars
                plotArea.selectAll("rect")
                    .data(summedArray)
                    .enter()
                    .append("rect")
                    .attr("x", d => xScale(d.OrgCode))
                    .attr("y", d => yScale(0))
                    .attr("width", xScale.bandwidth())
                    .attr("height", 0)
                    .attr("fill", d => colorScale(d.OrgCode))
                    .attr("opacity", 0.8)
                    .on("mouseover", function(event, d) {
                        const xPos = event.pageX;
                        const yPos = event.pageY;

                        
/***************************************************************
                      Tooltip
***************************************************************/    
                        // Find organization name by OrgCode
                        const orgName = dataset.find(item => item.OrgCode === d.OrgCode).OrgName;
                        d3.select(".tooltip")
                            .style("opacity", .9)
                            .style("left", xPos + "px")
                            .style("top", yPos + "px")
                            .html(`<strong>OrgName:</strong> ${orgName}<br><strong>OrgCode:</strong> ${d.OrgCode}<br><strong>Total Admissions:</strong> ${d.TotalAdmissions.toLocaleString()}`);
                    })
                    .on("mouseout", function() {
                        d3.select(".tooltip").style("opacity", 0);
                    })
                    .classed('highlight', false)
                    .transition()
                    .duration(1000)
                    .delay((d, i) => i * 20)
                    .attr("y", d => yScale(d.TotalAdmissions))
                    .attr("height", d => graphHeight - yScale(d.TotalAdmissions));
/***************************************************************
                      Scale Axis
***************************************************************/    
 
                // Add x axis
                plotArea.append("g")
                    .attr("class", "x-axis")
                    .attr("transform", `translate(0, ${graphHeight})`)
                    .call(d3.axisBottom(xScale))
                    .selectAll("text")
                    .style("text-anchor", "middle")
                    .attr("dy", "1em")
                    .style("font-weight", "bold");
                    

                // Add y axis
                plotArea.append("g")
                    .attr("class", "y-axis")
                    .call(d3.axisLeft(yScale))
                    .selectAll("text")
                    .style("font-weight", "bold")
                    .attr("dx", "-0.5em");
            }

            // Initial call to update chart with default year
            updateChart(uniqueYears[0]);

            // Add event listener to the year selector
            document.getElementById("yearSelector").addEventListener("change", function() {
                const selectedYear = parseInt(this.value);
                updateChart(selectedYear);
            });
        });