// Funnel Chart created using D3.js (Data-Driven Documents)
// Adapted from examples and documentation available on the official D3.js website (d3js.org)
// Additional inspiration from lectures

    // Load the dataset from JSON file
     d3.json("new_dataset_2.json").then(function(dataset) {
       // Extract unique years from the dataset
        const uniqueYears = Array.from(new Set(dataset.map(d => d.Year)));

        // Populate the dropdown menu with year options
        const yearSelector = d3.select("#yearSelector")
            .on("change", updateChart);;
        yearSelector.selectAll("option")
            .data(uniqueYears)
            .enter()
            .append("option")
            .attr("value", d => d)
            .text(d => d);

        // Define color scale
        const colorScale = d3.scaleOrdinal()
            .domain(dataset.map(d => d.Organization))
            .range(d3.schemeCategory10);

        // Function to update the chart based on the selected year
        function updateChart() {
            // Get the selected year from the dropdown
            const selectedYear = yearSelector.property("value");

            // Filter dataset by selected year
            const filteredData = dataset.filter(d => d.Year == selectedYear);

            // Calculate the sum for each organization
            const summedData = d3.rollup(filteredData, v => d3.sum(v, d => d.Attendance), d => d.Organization);

            // Convert the summed data to an array of objects and sort in descending order
            let summedArray = Array.from(summedData, ([Organization, Attendance]) => ({ Organization, Attendance }));
            summedArray.sort((a, b) => b.Attendance - a.Attendance);

            // SVG size
            const width = 1200;
            const height = 900;

            // Margins
            const margin = { top: 50, right: 50, bottom: 50, left: 200 }; // Adjust left margin for labels

            // The actual chart size within the SVG area.
            const graphWidth = width - margin.left - margin.right;
            const graphHeight = height - margin.top - margin.bottom;

            // Padding between rectangles
            const padding = 20;

            // Rectangle size reduction factor
            const reductionFactor = 0.8;

            // Remove existing elements
            d3.select("svg").remove();

            // Create an SVG to draw to
            const svg = d3.select(".chart")
                .append("svg")
                .attr("width", width)
                .attr("height", height);

            // Create a group to contain the whole graph.
            const plotArea = svg.append('g')
                .attr("transform", `translate(${margin.left},${margin.top})`);

            // Calculate total attendance
            const totalAttendance = d3.sum(summedArray, d => d.Attendance);

            // Add total attendance text
            plotArea.append("text")
                .attr("class", "total-attendance")
                .attr("x", graphWidth / 2)
                .attr("y", -20)
                .text(`Total Admissions: ${totalAttendance.toLocaleString()}`) // Format with commas
                .attr("dy", "0.5em") // Adjust vertical alignment
                .attr("text-anchor", "middle")
                .style("font-size", "18px"); // Increase font size

            // Set up funnel chart
            let cumulativeHeight = 0; // Initialize cumulative height
            summedArray.forEach((d, i) => {
                const rectHeight = (graphHeight * d.Attendance) / totalAttendance * reductionFactor; // Reduce height
                const rectWidth = graphWidth * (d.Attendance / summedArray[0].Attendance) * reductionFactor; // Reduce width
                const xPosition = (graphWidth - rectWidth) / 2; // Center the rectangles

                // Append the rectangle
                const bar = plotArea.append("rect")
                    .attr("x", xPosition)
                    .attr("y", cumulativeHeight)
                    .attr("width", rectWidth)
                    .attr("height", rectHeight)
                    .attr("fill", colorScale(d.Organization))
                    .attr("opacity", 0.8) // Adjust the opacity if needed;
                    .on("mouseover", function() {
                        d3.select(this).attr("fill", darkenColor(colorScale(d.Organization), 0.8)); // Darken color on mouseover
                        tooltip.style("opacity", 1)
                            .html(`<strong>${d.Organization}</strong><br>Attendance: ${d.Attendance.toLocaleString()}`)
                            .style("left", (event.pageX + 210) + "px")
                            .style("top", (event.pageY - 90) + "px");
                    })
                    .on("mouseout", function() {
                        d3.select(this).attr("fill", colorScale(d.Organization)); // Restore original color on mouseout
                        tooltip.style("opacity", 0);
                    });

                // Add attendance count inside the rectangle
                plotArea.append("text")
                    .attr("x", xPosition + rectWidth / 2)
                    .attr("y", cumulativeHeight + rectHeight / 2)
                    .text(d.Attendance.toLocaleString()) // Format with commas
                    .attr("dy", "0.35em")
                    .attr("text-anchor", "middle")
                    .style("fill", "black");

                cumulativeHeight += rectHeight + padding; // Increment cumulative height with rect height and padding
            });

            // Add legend
            const legend = svg.append("g")
                .attr("class", "legend")
                .attr("transform", `translate(${margin.left},${margin.top})`);

            const legendSpacing = 20; // Adjust spacing between legend items

            // Add legend title
            legend.append("text")
                .attr("x", 1180)
                .attr("y", -margin.top / 2)
                .attr("class", "legend-title")
                .text("Organization Legend")
                .style("font-size", "16px")
                .style("font-weight", "bold");

            // Add legend items
            const legendItems = legend.selectAll(".legend-item")
                .data(summedArray)
                .enter()
                .append("g")
                .attr("class", "legend-item")
                .attr("transform", (d, i) => `translate(0, ${i * legendSpacing})`);

            legendItems.append("rect")
                .attr("x", 1080)
                .attr("y", 0)
                .attr("width", 10)
                .attr("height", 10)
                .attr("fill", d => colorScale(d.Organization));

            legendItems.append("text")
                .attr("x", 1100)
                .attr("y", 10)
                .text(d => d.Organization)
                .style("font-size", "14px")
                .style("font-weight", "normal")
                .style("text-anchor", "start");
        }

        // Initial call to update chart with default year
        updateChart();


        // Helper function to darken color
        function darkenColor(color, amount) {
            return d3.hsl(color).darker(amount).toString();
        }

        // Tooltip
        const tooltip = d3.select(".tooltip")
            .style("opacity", 0)
            .style("border-radius", "5px")
            .style("padding", "10px")
            .style('position', 'absolute');
    });
