  /***************************************************************
           DEFINING SVG AREA
***************************************************************/

// Define margins for the chart
const margin = { top: 60, right: 230, bottom: 50, left: 50 };
// Calculate width and height of the chart area
const width = 1500 - margin.left - margin.right;
const height = 600 - margin.top - margin.bottom;

// Select the SVG element and set its width and height
const svg = d3.select(".chart")
  .select('svg')
  .attr("width", width + margin.left + margin.right)
  .attr("height", height + margin.top + margin.bottom)
  .append("g")
  .attr("transform", `translate(${margin.left},${margin.top})`);

let line; // Define the line variable globally

/***************************************************************
           DATA PREPARATION
***************************************************************/
// Load CSV data and perform operations
d3.csv("oldnewdata.csv").then(function(data) {
  // Parse the date and extract the year
  const parseDate = d3.timeParse("%Y-%m-%d");
  data.forEach(function(d) {
    d.Period = parseDate(d.Period);
    d.Year = d.Period.getFullYear(); // Extract the year from the date
  });

  // Aggregate the data for every year and ParentOrg
  const aggregatedData = d3.rollup(data, v => d3.sum(v, d => +d.TotalAdmissions), d => d.Year, d => d.ParentOrg);

  // Convert the aggregated data to an array of objects
  const aggregatedArray = [];
  aggregatedData.forEach((value, year) => {
    value.forEach((totalAdmissions, parentOrg) => {
      aggregatedArray.push({ Year: year, ParentOrg: parentOrg, TotalAdmissions: totalAdmissions });
    });
  });

  // Color palette with ordinal scale
  const color = d3.scaleOrdinal()
    .domain(aggregatedArray.map(d => d.ParentOrg))
    .range(d3.schemeCategory10);
 
  // Set up the initial line chart with all ParentOrgs
  const x = d3.scaleBand()
    .domain(aggregatedArray.map(d => d.Year))
    .range([50, width])
    .padding(0.1);

  // Append x-axis to SVG
  const xAxis = svg.append("g")
    .attr("class", "x-axis") // Set class attribute
    .attr("transform", `translate(0,${height})`) // Set transformation
    .call(d3.axisBottom(x).tickSizeOuter(0)); // Call axis function and set tick size

  // Append text to SVG
  svg.append("text")
    .attr("text-anchor", "end")
    .attr("x", width)
    .attr("y", height + 50)
    .text("Year");

/***************************************************************
           CREATING LEGEND
***************************************************************/
  // Append legend to SVG
  const legend = svg.append('g')
    .attr("class", "legend")
    .attr("transform", `translate(${width - 20}, ${margin.top})`);


    // Function to update legend
  function updateLegend() {
    // Remove existing legend items
    legend.selectAll("*").remove();

    // Create legend items
    const legendItems = legend.selectAll(".legend-item")
        .data(Array.from(new Set(aggregatedArray.map(d => d.ParentOrg))))
        .enter().append("g")
        .attr("class", "legend-item")
        .attr("transform", (d, i) => `translate(0, ${i * 20})`);
    
    // Add colored rectangles for each line
    legendItems.append("rect")
    .attr("x", 0)
    .attr("y", 0)
    .attr("width", 10)
    .attr("height", 10)
    .attr("fill", d => color(d));
     // Add text labels for each line
    legendItems.append("text")
    .attr("x", 15)
    .attr("y", 9)
    .text(d => d)
    .style("font-size", "12px")
    .style("fill", "black");
}

updateLegend();

  /***************************************************************
           CREATING LINE CHART
***************************************************************/
  // Define y scale
  const y = d3.scaleLinear()
    .domain([0, d3.max(aggregatedArray, d => +d.TotalAdmissions)])
    .nice()
    .range([height, 0]);
  
    // Append y-axis to SVG
  const yAxis = svg.append("g")
    .attr("class", "y-axis")
    .attr("transform", "translate(60,0)")
    .call(d3.axisLeft(y).tickFormat(d3.format(".2s")));
  
  // Append text to y-axis
  yAxis.append("text")
    .text("Number of Admissions")
    .attr("y", height / 2)
    .attr("transform", "translate(-300,350) rotate(270)")
    .style("fill", "black")
    .attr("text-anchor", "start");

  // Create a tooltip div element
  const tooltip = d3.select("body")
    .append("div")
    .attr("class", "tooltip")

// Function to draw all lines together
function drawAllLines() {
  // Calculate the maximum total admissions
  const maxTotalAdmissions = d3.max(aggregatedArray, d => +d.TotalAdmissions);
  // Update y domain and redraw y-axis
  y.domain([0, maxTotalAdmissions]).nice();
  yAxis.transition().duration(500).call(d3.axisLeft(y).tickFormat(d3.format(".2s")));
  svg.selectAll(".line").remove(); // Remove previous lines

  // Define the line generator function for final positions
  const line = d3.line()
    .x(d => x(d.Year)+40) // Set x-coordinate
    .y(d => y(d.TotalAdmissions)); // Set y-coordinate
    
  // Append lines to SVG
  const lines = svg.append("g")
      .selectAll(".line")
      .data(Array.from(new Set(aggregatedArray.map(d => d.ParentOrg))))
      .enter().append("path")
      .attr("class", "line")
      .attr("fill", "none")
      .attr("stroke", d => color(d))
      .attr("stroke-width", 2)
      .attr("d", d => {
        // Define the line generator function for initial points
        const lineGenerator = d3.line()
            .x(d => x(d.Year) - width) // Set x-coordinate to a fixed starting point on the left side
            .y(d => y(d.TotalAdmissions)); // Set y-coordinate
        return lineGenerator(aggregatedArray.filter(item => item.ParentOrg === d));
        })
        .on("mouseover", function(event, d) { // Pass event and data point to event handler
          showTooltip(event, d); // Pass data point to showTooltip function
        })
        .on("mouseout", hideTooltip);

  // Attach event listeners to lines
  attachLineEventListeners();

  // Animate the lines
  lines.transition()
      .duration(1000) // Adjust duration as needed
      .delay((d, i) => i * 100) // Delay each line animation for a staggered effect
      .attr("d", d => line(aggregatedArray.filter(item => item.ParentOrg === d)));
}

// Call drawAllLines to draw all lines together initially
drawAllLines();

// Function to attach event listeners to the lines
function attachLineEventListeners() {
  svg.selectAll(".line")
      .on("mouseover", function(event, d) {
          d3.select(this) // Select the hovered line
              .transition() // Apply smooth transition
              .duration(100) // Set transition duration
              .attr("stroke-width", 6); // Increase the stroke width
          showTooltip(event, d);    
      })
      .on("mouseout", function(event, d) {
          d3.select(this) // Select the hovered line
              .transition() // Apply smooth transition
              .duration(100) // Set transition duration
              .attr("stroke-width", 2); // Restore the original stroke width
          hideTooltip();
      });
}

// Call the function to attach event listeners after drawing the initial lines
attachLineEventListeners();

  /***************************************************************
           CREATING DROPDOWN ELEMENT
***************************************************************/
  // Create a dropdown select element
  const dropdown = d3.select('.chart')
    .select('#select')
    .append('select')
    .attr("class", "dropdown")
    .on("change", dropdownChange);
  
  // Select all option elements within the dropdown and bind data
  dropdown.selectAll("option")
    // Create new options for each unique ParentOrg in aggregatedArray
    .data(Array.from(new Set(aggregatedArray.map(d => d.ParentOrg))))
    .enter().append("option") // Append option elements
    .attr("value", d => d) // Set value attribute of options
    .text(d => d); // Set text content of options

  // Apply CSS positioning
  dropdown.style("position", "absolute")
    .style("left", (margin.left + 120) + "px")
    .style("top", "160px");

    dropdown.append('option')
    .attr('value', "ALL")
    .text("ALL");

    const svgContainer = d3.select(".chart").select('svg');
    // Append text element
    svgContainer.append("text")
    .attr("x", margin.left+90)
    .attr("y", 10) 
    .attr("text-anchor", "end")
    .text("Choose region:"); 

  // Function to update the chart based on the selected value from the dropdown
  function dropdownChange() {
    const selectedParentOrg = d3.select(this).property("value");

    if (selectedParentOrg === "ALL") {
      svg.selectAll(".label").remove();
      svg.selectAll("circle").remove();
      drawAllLines(); // Call drawAllLines if "ALL" is selected

  } else {
      const filteredData = aggregatedArray.filter(d => d.ParentOrg === selectedParentOrg);

    // Update the Y scale domain based on the filtered data
      const maxY=d3.max(filteredData, d => +d.TotalAdmissions),
            minY=d3.min(filteredData, d => +d.TotalAdmissions);
    
    // Set the domain of the y-axis scale to the specified minimum and maximum values and adjust for readability
    y.domain([minY, maxY]).nice();

    // Redraw the Y axis
    yAxis.transition().duration(500).call(d3.axisLeft(y).tickFormat(d3.format(".2s")));
    redrawLines(filteredData);

    drawLabels(filteredData);

    svg.append("path")
    .datum(filteredData)
    .attr("class", "line")
    .attr("fill", "none")
    .attr("stroke", color(selectedParentOrg))
    .attr("stroke-width", 2)
    .attr("d", line);
  }
}

// Function to redraw lines based on filtered data
function redrawLines(data) {
  svg.selectAll(".line").remove(); // Remove previous lines
  
  const line = d3.line()
    .x(d => x(d.Year)+42)
    .y(d => y(d.TotalAdmissions));

   const lines = svg.append("g")
    .selectAll(".line")
    .data(Array.from(new Set(data.map(d => d.ParentOrg))))
    .enter().append("path")
    .attr("class", "line")
    .attr("fill", "none")
    .attr("stroke", d => color(d))
    .attr("stroke-width", 2)
    .attr("d", d => line(data.filter(item => item.ParentOrg === d)))
    .on("mouseover", function(event, d) { // Pass event and data point to event handler
      showTooltip(event, d); // Pass data point to showTooltip function
  })
    .on("mouseout", hideTooltip);
  }   
// Function to draw labels for the data points
function drawLabels(data) {
  // Remove existing labels and circles
  svg.selectAll(".data-point").remove();

  /***************************************************************
           CREATING DATA LABELS
***************************************************************/
  // Append circles and labels to the data points
  const dataPoints = svg.selectAll(".data-point")
    .data(data)
    .enter()
    .append("g")
    .attr("class", "data-point")
    .on("mouseover", function() {
      d3.select(this).select(".label")
        .transition()
        .duration(100)
        .style("font-size", "12px") // increase the font size of the label
        .style("fill", "red"); // change the color of the label
    })
    .on("mouseout", function() {
      d3.select(this).select(".label")
        .transition()
        .duration(100)
        .style("font-size", "10px") // restore the original font size of the label
        .style("fill", "black"); // restore the original color of the label
    });

  // Append circles to the data points
  dataPoints.append("circle")
    .attr("class", "circle")
    .attr("cx", d => x(d.Year) + 42) // X-coordinate of the circle
    .attr("cy", d => y(d.TotalAdmissions)) // Y-coordinate of the circle
    .attr("r", 3) // Radius of the circle
    .attr("fill", "#0C359E"); // Color of the circle

  // Append text labels to the data points
  dataPoints.append("text")
    .attr("class", "label")
    .attr("x", d => x(d.Year) + 30) // Position the label horizontally based on the x-coordinate of the data point
    .attr("y", d => y(d.TotalAdmissions) - 10) // Position the label vertically based on the y-coordinate of the data point
    .text(d => d.TotalAdmissions) // Set the text content of the label to the TotalAdmissions value
    .style("text-anchor", "middle") // Center-align the text horizontally
    .style("font-size", "10px") // Set the font size
    .style("fill", "black"); // Set the text color
}  

/***************************************************************
           TOOLTIP FUNCTIONS
***************************************************************/
// Function to show the tooltip when hovering over a data point
function showTooltip(event, d) {
  console.log("Hovered Data Point:", d);
  tooltip.transition()
      .duration(100)
      .style("opacity", .7);
  tooltip.html(`Parent Organisation: ${d}`)
      .style("left", (event.pageX) + "px")
      .style("top", (event.pageY - 28) + "px");
}

    // Function to hide the tooltip when not hovering over a data point
function hideTooltip() {
  tooltip.transition()
      .duration(100)
      .style("opacity", 0);
}
});